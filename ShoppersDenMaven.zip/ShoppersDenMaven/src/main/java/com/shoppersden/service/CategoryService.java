package com.shoppersden.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shoppersden.dao.CategoryDaoIface;
import com.shoppersden.model.Category;

@Service
public class CategoryService implements CategoryServiceIface {
	@Autowired
	CategoryDaoIface categoryDaoIface;
	
	public String addCategoryService(Category category) {
		return categoryDaoIface.addCategory(category);

	}

	
	public List<Category> showCategoryService() {
	return categoryDaoIface.showCategory();
		
	}

	public void updateCategoryService(Category cate) {
		categoryDaoIface.updateCategory(cate);
	}

	
	public void deleteCategoryService(int cid) {
		 categoryDaoIface.deleteCategory(cid);
	}

	public Category getCategoryService(int id) {
		return categoryDaoIface.getCategory(id);
	}
	

}
