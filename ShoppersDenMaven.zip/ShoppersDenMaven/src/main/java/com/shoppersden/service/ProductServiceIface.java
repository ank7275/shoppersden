package com.shoppersden.service;

import java.util.List;

import com.shoppersden.model.Product;

public interface ProductServiceIface {
	String addProductService(Product obj);

	String removeProductService(int id);

	String updateProductService(Product obj);

	List<Product> searchByCategoryService(int sid);

	List<Product> getAllProductService();

	List<Product> getAllProductAdminService(String name);

	Product getProductService(int id);

	List<Product> getProductsSearchService(String val);
	
    void qtyUpdateProductService(String name,int qty); 
}
