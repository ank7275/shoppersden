package com.shoppersden.service;

import java.util.List;

import com.shoppersden.model.Category;

public interface CategoryServiceIface {
	
	public String addCategoryService(Category category);
	public List<Category> showCategoryService();
	public void updateCategoryService(Category category);
	public void deleteCategoryService(int cid);
	public Category getCategoryService(int id);

}
