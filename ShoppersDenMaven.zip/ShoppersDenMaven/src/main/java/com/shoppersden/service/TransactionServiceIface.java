package com.shoppersden.service;

import java.util.List;

import com.shoppersden.model.Transactions;

public interface TransactionServiceIface {
	void insertTransactionService(Transactions transactions);
	List<Transactions> getAllTransactions();
}
