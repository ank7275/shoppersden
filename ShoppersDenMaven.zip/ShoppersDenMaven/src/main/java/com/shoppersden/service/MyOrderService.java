package com.shoppersden.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shoppersden.dao.MyOrderDaoIface;
import com.shoppersden.model.MyOrders;

@Service
public class MyOrderService implements MyOrderServiceIface {
	@Autowired
	MyOrderDaoIface myOrderDaoIface;

	public void addOrderService(MyOrders myOrders) {
		myOrderDaoIface.addOrder(myOrders);
	}

	public List<Integer> getOrdersService(String id) {
		return myOrderDaoIface.getOrders(id);
	}

	public void cancelOrderService(int oid) {
		myOrderDaoIface.cancelOrder(oid);		
	}

}
