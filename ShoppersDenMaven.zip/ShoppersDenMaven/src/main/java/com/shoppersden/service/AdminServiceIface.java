package com.shoppersden.service;

import com.shoppersden.model.Admin;

public interface AdminServiceIface {
	String registerAdminService(Admin admin);

	Admin verifyAdminService(String id, String pass);
	
	String checkEmailExistanceService(String adminId);

}
