package com.shoppersden.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shoppersden.dao.CustomerDaoIface;
import com.shoppersden.model.Customer;

@Service
public class CustomerService implements CustomerServiceIface {
	@Autowired
	CustomerDaoIface customerDaoIface;

	@Override
	public String addCustomerService(Customer c) {
		return customerDaoIface.addCustomer(c);
	}

	@Override
	public Customer verifyCustomerService(String email, String pass) {
		return customerDaoIface.verifyCustomer(email, pass);
	}

	@Override
	public String updateCustomerService(Customer customer) {
		return customerDaoIface.updateCustomer(customer);
	}

	@Override
	public Customer getCustomerDetailsService(String uid) {
		return customerDaoIface.getCustomerDetails(uid);
	}

	public int validateIdService(String id) {
		return customerDaoIface.validateId(id);
	}

	public int updatePasswordService(String id, String pass) {
		return customerDaoIface.updatePassword(id, pass);
	}

}
