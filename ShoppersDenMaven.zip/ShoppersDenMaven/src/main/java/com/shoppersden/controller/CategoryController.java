package com.shoppersden.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.shoppersden.dao.CategoryDaoIface;
import com.shoppersden.model.Category;

/**
 * @author Vijay
 *
 */
@Controller
public class CategoryController {
	@Autowired
	CategoryDaoIface categoryDaoIface;

	@RequestMapping("/categoryForm")
	public String showCategoryForm() {
		return "Category";
	}

	@RequestMapping("/addCategory")
	public String submitForm(@ModelAttribute Category category, Model m) {
		if (categoryDaoIface.addCategory(category) != null) {
			m.addAttribute("msg", categoryDaoIface.addCategory(category));
			return "Category";
		} else {
			return "redirect:/showCategory";
		}
	}

	@RequestMapping("/showCategory")
	public ModelAndView show() {

		List<Category> category = categoryDaoIface.showCategory();

		return new ModelAndView("CategoryShow", "category", category);

	}

	@RequestMapping("/RemoveCategory")
	public String deleteCategory(@RequestParam("cid") int cid) {
		categoryDaoIface.deleteCategory(cid);
		return "redirect:/showCategory";
	}

}
