package com.shoppersden.controller;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.ServletConfigAware;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.servlet.ModelAndView;

import com.shoppersden.model.Cart;
import com.shoppersden.service.AddCartServiceIface;

/**
 * @author Ankit
 *
 */
@Controller
public class CartController implements ServletConfigAware, ServletContextAware {

	@Autowired
	AddCartServiceIface addCartServiceIface;
	ServletConfig config;
	ServletContext context;

	@Override
	public void setServletContext(ServletContext servletContext) {
		this.context = servletContext;

	}

	@Override
	public void setServletConfig(ServletConfig servletConfig) {
		this.config = servletConfig;
	}

	@RequestMapping("/AddToCart")
	public String addToCart(@RequestParam("id") int id, @RequestParam("name") String name,
			@RequestParam("price") int price, @RequestParam("qty") int qty, HttpServletRequest request, Model m) {
		HttpSession session = request.getSession();
		Cart cartObj = new Cart(id, name, price, qty);
		addCartServiceIface.AddToCartService(cartObj);
		context = config.getServletContext();
		context.setAttribute("cartsize", addCartServiceIface.cartSize());
		if (session.getAttribute("cname") == null) {
			return "redirect:/home";
		} else {
			return "redirect:/CustomerPage";
		}

	}

	@RequestMapping("/removeCart")
	public String removeFromCart(@RequestParam("name") String name) {
		addCartServiceIface.removeCartService(name);
		return "redirect:/displayCart";
	}

	@RequestMapping("/decreaseQty")
	public ModelAndView decreaseQty(@RequestParam("name") String name, HttpServletRequest request) {
		addCartServiceIface.decreaseQtyService(name);
		return new ModelAndView("redirect:/displayCart");
	}

	@RequestMapping("/increaseQty")
	public ModelAndView increaseQty(@RequestParam("name") String name) {
		String str = null;
		str = addCartServiceIface.increaseQtyService(name);
		if (str.equals("increased")) {
			return new ModelAndView("redirect:/displayCart");
		} else {
			return new ModelAndView("redirect:/displayCart", "msg", str);
		}
	}

	@RequestMapping("/displayCart")
	public ModelAndView viewCart(Model m, HttpServletRequest request) {
		if (addCartServiceIface.cartSize() == 0) {
			m.addAttribute("msg1", "Cart is empty");
			context.setAttribute("cartsize", 0);
			return new ModelAndView("ViewCart");
		} else {
			context.setAttribute("cartsize", addCartServiceIface.cartSize());
			m.addAttribute("cart", addCartServiceIface.displayCartService());
			m.addAttribute("msg", request.getParameter("msg"));
			return new ModelAndView("ViewCart");
		}
	}

}
