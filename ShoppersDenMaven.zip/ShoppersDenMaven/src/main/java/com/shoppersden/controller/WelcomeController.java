package com.shoppersden.controller;

import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.ServletConfigAware;
import org.springframework.web.context.ServletContextAware;

import com.shoppersden.model.Category;
import com.shoppersden.model.Product;
import com.shoppersden.service.AddCartServiceIface;
import com.shoppersden.service.CategoryServiceIface;
import com.shoppersden.service.ProductServiceIface;

@Controller
public class WelcomeController implements ServletConfigAware, ServletContextAware {
	private ServletContext context;
	private ServletConfig config;
	@Autowired
	ProductServiceIface productserviceIface;

	@Autowired
	CategoryServiceIface categoryServiceIface;

	@Autowired
	AddCartServiceIface addCartServiceIface;

	@Override
	public void setServletContext(ServletContext servletContext) {
		this.context = servletContext;
	}

	@Override
	public void setServletConfig(ServletConfig servletConfig) {
		this.config = servletConfig;

	}

	@RequestMapping("/home")
	public String indexPage(Model m) {
		context = config.getServletContext();
		List<Product> products = productserviceIface.getAllProductService();
		List<Category> categories = categoryServiceIface.showCategoryService();
		context.setAttribute("category", categories);
		m.addAttribute("product", products);

		m.addAttribute("cartsize", addCartServiceIface.cartSize());

		return "index";
	}

}
