package com.shoppersden.controller;

import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.ServletConfigAware;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.servlet.ModelAndView;

import com.shoppersden.model.Product;
import com.shoppersden.service.CategoryServiceIface;
import com.shoppersden.service.ProductServiceIface;

/**
 * @author Vijay
 *
 */
@Controller
public class ProductController implements ServletConfigAware, ServletContextAware {
	@Autowired
	ProductServiceIface productIface;
	@Autowired
	CategoryServiceIface categoryIface;
	ServletConfig config;
	ServletContext context;

	@Override
	public void setServletContext(ServletContext servletContext) {
		this.context = servletContext;

	}

	@Override
	public void setServletConfig(ServletConfig servletConfig) {
		this.config = servletConfig;

	}

	@RequestMapping("/Productform")
	public String showForm(Model m) {
		m.addAttribute("product",new Product());
		return "Productform";
	}

	@RequestMapping("/AddProduct")
	public String addProduct(@Valid @ModelAttribute Product product,BindingResult br) {
		if(br.hasErrors()){
			return "Productform";
		}
		else{
		productIface.addProductService(product);
		return "redirect:/showAllProductAdmin";
		}
	}

	@RequestMapping("/RemoveProduct")
	public String removeProduct(@RequestParam("id") int id) {
		productIface.removeProductService(id);
		return "redirect:/showAllProductAdmin";
	}

	@RequestMapping("/ProductUpdateForm")
	public ModelAndView updateProductForm(@RequestParam("id") int id) {
		Product product = productIface.getProductService(id);
		return new ModelAndView("UpdateProductForm", "product", product);
	}

	@RequestMapping("/UpdateProduct")
	public String updateProduct(@ModelAttribute Product product) {
		productIface.updateProductService(product);
		return "redirect:/showAllProductAdmin";
	}

	@RequestMapping("/showAllProductAdmin")
	public ModelAndView showAllProductAdmin(HttpServletRequest request, HttpSession session) {
		session = request.getSession();
		String name = (String) session.getAttribute("name");
		context = config.getServletContext();
		context.setAttribute("category", categoryIface.showCategoryService());
		List<Product> product = productIface.getAllProductAdminService(name);
		return new ModelAndView("Admin", "product", product);
	}

	@RequestMapping("/AjaxSearch")
    public ModelAndView showAllSearchProduct(@RequestParam("val") String val) {
		List<Product> products = productIface.getProductsSearchService(val);
		return new ModelAndView("Search","products",products);
    }
    
    @RequestMapping("/SearchByCategory")
    public ModelAndView searchByCategory(@RequestParam("id") int id) {
    	List<Product> products=productIface.searchByCategoryService(id);
    	return new ModelAndView("SearchByCategory","CategoryProducts",products);
    	
    }

}
