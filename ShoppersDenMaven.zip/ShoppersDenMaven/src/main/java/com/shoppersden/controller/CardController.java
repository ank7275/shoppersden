package com.shoppersden.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.shoppersden.dao.CardDaoIface;
import com.shoppersden.model.Card;

@Controller
public class CardController {
	@Autowired
	CardDaoIface cardDaoIface;

	@RequestMapping("/cardForm")
	public String showFrom(Model m) {
		m.addAttribute("card", new Card());
		return "Card";
	}

	@RequestMapping("/addcard")
	public String addCard(@Valid @ModelAttribute("card") Card card ,BindingResult br) {
		if (br.hasErrors()) {  
            return "Card";  
        }  
        else {  
        	cardDaoIface.addCard(card);
    		return "redirect:/ViewCards";
        }  
	}

	@RequestMapping("/deleteCard")
	public String deleteCard(@RequestParam("cno") String cno) {
		cardDaoIface.deleteCard(cno);
		return "redirect:/ViewCards";
	}
}
