package com.shoppersden.test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import com.shoppersden.model.Category;

class CategoryTest {

	@Test
	public void testGetters() {
		Category obj = new Category();
		obj.setCatId(1);
		assertEquals(1, obj.getCatId());

		obj.setCatName("Mens");
		assertEquals("Mens", obj.getCatName());

	}

	/*
	 * @Test public void testAddCategory() { Category category=new Category();
	 * category.setCatId(1); category.setCatName("toys");
	 * assertEquals("Category Added Successfully...", new
	 * CategoryDao().addCategory(category));
	 * assertEquals("Category cannot be added", new
	 * CategoryDao().addCategory(null)); }
	 * 
	 * @Test public void testDeleteCategory() { assertEquals("Record Deleted..", new
	 * CategoryDao().deleteCategory(1)); assertEquals("Record cannot be deleted",
	 * new CategoryDao().deleteCategory(-1)); }
	 */

}
