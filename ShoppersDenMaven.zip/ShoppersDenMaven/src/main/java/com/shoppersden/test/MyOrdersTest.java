package com.shoppersden.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.shoppersden.model.MyOrders;

class MyOrdersTest {

	@Test
	public void testGetters() {
		
		MyOrders myorder=new MyOrders();
		
		myorder.setOrderid(1);
		assertEquals(1,myorder.getOrderid());
		
		myorder.setUserid("aa@gmail.com");
		assertEquals("aa@gmail.com",myorder.getUserid());
	}

}
