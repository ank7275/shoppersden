package com.shoppersden.test;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

import com.shoppersden.model.Transactions;

class TransactionsTest {
	@Test
	public void testGetters() {
		Transactions transactions = new Transactions();

		transactions.setTrId(2);
		assertEquals(2, transactions.getTrId());

		transactions.setAddress("abcd");
		assertEquals("address", transactions.getAddress());

		transactions.setcAddress("abcd1");
		assertEquals(5, transactions.getcAddress());

		transactions.setDdate(null);
		assertEquals(null, transactions.getDdate());

		transactions.setOdate(null);
		assertEquals(null, transactions.getOdate());

		transactions.setCardNo("3548584568857656");
		assertEquals(677, transactions.getCardNo());
		
		transactions.setcName("ankit");
		assertEquals(null, transactions.getcName());
		
		transactions.setOid(2);
		assertEquals(1, transactions.getOid());
		
		transactions.setStatus("Delivered");
		assertEquals("Delivered", transactions.getStatus());
		
		transactions.setTotalAmt("2300");
		assertEquals("2300", transactions.getTotalAmt());
		
		transactions.setTotQty("5");
		assertEquals("5",transactions.getTotQty());
		
		transactions.setTrId(2323);
		assertEquals(2323, transactions.getTrId());

	}

}
