package com.shoppersden.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.shoppersden.dao.ProductDao;
import com.shoppersden.model.Product;

class ProductTest {

	@Test
	public void testGetters() {
		Product obj = new Product();
		obj.setProId(1);
		assertEquals(1, obj.getProId());
		obj.setProName("Shirt");
		assertEquals("Shirt", obj.getProName());
		obj.setProImg("url");
		assertEquals("url", obj.getProImg());
		obj.setProPrice("320");
		assertEquals(320, obj.getProPrice());
		obj.setProQty("12");
		assertEquals(12, obj.getProQty());
		obj.setProDesc("Good");
		assertEquals("Good", obj.getProDesc());
		obj.setCatId(1);
		assertEquals(1, obj.getCatId());
		obj.setPostedBy("admin");
		assertEquals("admin", obj.getPostedBy());
	}

	@Test
	public void testAddProduct() {
		Product obj = new Product();
		obj.setProId(1);
		obj.setProName("Shirt");
		obj.setProImg("url");
		obj.setProPrice("320");
		obj.setProQty("12");
		obj.setProDesc("Good");
		obj.setCatId(1);
		obj.setPostedBy("admin");
		assertEquals("product added", new ProductDao().addProduct(obj));
		assertEquals("product cannot be null", new ProductDao().addProduct(null));
	}

	@Test
	public void testRemoveProduct() {
		assertEquals("product cannot be deleted", new ProductDao().removeProduct(-1));
		assertEquals("Product deleted", new ProductDao().removeProduct(1));
	}

	@Test
	public void testUpdateProduct() {
		Product obj = new Product();
		obj.setProId(1);
		obj.setProName("Shirt");
		obj.setProImg("url");
		obj.setProPrice("320");
		obj.setProQty("12");
		obj.setProDesc("Good");
		obj.setCatId(1);

		assertEquals("Successfully updated", new ProductDao().updateProduct(obj));

		assertEquals("Product cannot be update", new ProductDao().updateProduct(null));
	}

	@Test
	public void testSearchCategory() {
		ProductDao obj = new ProductDao();
		assertEquals(null, obj.searchByCategory(-1));
		assertEquals(obj.searchByCategory(1), obj.searchByCategory(1));
	}

}
