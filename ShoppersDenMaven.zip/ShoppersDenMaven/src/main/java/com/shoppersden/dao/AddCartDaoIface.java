package com.shoppersden.dao;

import java.util.ArrayList;

import com.shoppersden.model.Cart;

public interface AddCartDaoIface {
	String AddToCart(Cart obj);
	ArrayList<Cart> displayCart();
	String removeCart(String name);
	String decreaseQty(String name);
	String increaseQty(String name);
	int cartSize();
	void setCart(ArrayList<Cart> cart);
}
