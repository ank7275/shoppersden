package com.shoppersden.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shoppersden.model.Cart;

@Repository
public class CartDao implements CartDaoIface {
	@Autowired
	SessionFactory sessionFactory;

	@Transactional
	public List<Cart> getAllOrderedItems() {
		List<Cart> carts = sessionFactory.getCurrentSession().createQuery("from Cart").list();
		return carts;
	}

	@Transactional
	public void saveAllorders(Cart cart) {
		sessionFactory.getCurrentSession().save(cart);
	}
}
