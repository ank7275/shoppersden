package com.shoppersden.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shoppersden.model.MyOrders;


/**
 * @author Ankit
 *
 */
@Repository
public class MyOrderDao implements MyOrderDaoIface {
	@Autowired
	SessionFactory sessionFactory;

	@Transactional
	public void addOrder(MyOrders myOrders) {
		sessionFactory.getCurrentSession().save(myOrders);
	}
	
	@Transactional
	public List<Integer> getOrders(String id){
		SQLQuery query=sessionFactory.getCurrentSession().createSQLQuery("select orderid from myorders1 where userid=:id");
		query.setParameter("id", id);
		query.executeUpdate();
		List<Integer>  myOrders=query.list();
		return myOrders;
	}
    @Transactional
	public void cancelOrder(int oid) {
		Query query=sessionFactory.getCurrentSession().createQuery("update Transactions set status=:status where oid=:oid");
		query.setParameter("status","cancelled");
		query.setParameter("oid", oid);
		query.executeUpdate();
	}
}
