package com.shoppersden.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shoppersden.model.Category;

/**
 * @author Vijay
 *
 */
@Repository
public class CategoryDao implements CategoryDaoIface {
	@Autowired
	SessionFactory sessionFactory;

	@Transactional
	public String addCategory(Category category) {
		String msg = this.checkCategoryExists(category.getCatName());
		if (msg == null) {
			Session session = sessionFactory.getCurrentSession();
			session.save(category);
			return null;
		} else {
			return msg;
		}
	}

	@Transactional
	public List<Category> showCategory() {
		Query query = sessionFactory.getCurrentSession().createQuery("from Category");
		List<Category> categories = query.list();
		return categories;
	}

	@Transactional
	public void updateCategory(Category category) {
		Session session = sessionFactory.getCurrentSession();
		session.update(category);
	}

	@Transactional
	public void deleteCategory(int cid) {
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery("delete from Category where catId=:cid");
		query.setParameter("cid", cid);
		query.executeUpdate();
	}

	@Transactional
	public Category getCategory(int id) {
		Category category = (Category) sessionFactory.getCurrentSession().get(Category.class, id);
		return category;
	}

	@Transactional
	public String checkCategoryExists(String name) {
		Query query = sessionFactory.getCurrentSession().createQuery("from Category where catName=:name");
		query.setParameter("name", name);
		List<Category> categories=query.list();
		if (!categories.isEmpty()) {
			return "Category already exists";
		} else {
			return null;
		}
	}

}
