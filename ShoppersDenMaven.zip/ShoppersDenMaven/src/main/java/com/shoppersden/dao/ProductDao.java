package com.shoppersden.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.shoppersden.model.Product;

@Repository
public class ProductDao implements ProductDaoIface {
	@Autowired
	SessionFactory sessionfactory;

	public SessionFactory getSessionfactory() {
		return sessionfactory;
	}

	public void setSessionfactory(SessionFactory sessionfactory) {
		this.sessionfactory = sessionfactory;
	}

	@Transactional
	public String addProduct(Product product) {
		HttpSession sess;
		ServletRequestAttributes servReq = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
		HttpServletRequest req = servReq.getRequest();
		sess = req.getSession();
		Session session = this.getSessionfactory().getCurrentSession();
		product.setPostedBy((String) sess.getAttribute("name"));
		int i = (Integer) session.save(product);
		if (i > 0) {
			return "product added";
		} else {
			return "product not added";
		}
	}

	@Transactional
	public String removeProduct(int id) {
		Session session = this.getSessionfactory().getCurrentSession();
		Query query = session.createQuery("delete from Product where proId=:Id");
		query.setParameter("Id", id);
		int i = query.executeUpdate();
		if (i > 0) {
			return "Product deleted";
		} else {
			return "Product cannot be deleted";
		}
	}

	@Transactional
	public String updateProduct(Product product) {
		Session session = this.getSessionfactory().getCurrentSession();
		session.update(product);
		return "product updated successfully";
	}

	@Transactional
	public List<Product> searchByCategory(int sid) {
		Query query = sessionfactory.getCurrentSession().createQuery("from Product where catId=:id");
		query.setParameter("id", sid);
		List<Product> products = query.list();
		return products;
	}

	@Transactional
	public List<Product> getAllProduct() {
		Query query = this.getSessionfactory().getCurrentSession().createQuery("FROM Product WHERE proQty>0");
		List<Product> products = query.list();
		return products;
	}

	@Transactional
	public List<Product> getAllProductAdmin(String name) {
		List<Product> products = null;
		if (name == null) {
			return products;
		}
		Query query = this.getSessionfactory().getCurrentSession().createQuery("FROM Product WHERE postedBy=:Name");
		query.setParameter("Name", name);
		List<Product> product = query.list();
		return product;

	}

	@Transactional
	public Product getProduct(int id) {

		Product product = (Product) this.getSessionfactory().getCurrentSession().get(Product.class, id);
		return product;
	}

	@Transactional
	public List<Product> getProductsSearch(String val) {
		List<Product> products = null;
		if (val == null || val.trim().equals("")) {
			products = this.getAllProduct();
		} else {

			Criteria criteria = this.getSessionfactory().getCurrentSession().createCriteria(Product.class);
			criteria.add(Restrictions.ilike("proName", val+"%"));
			products = criteria.list();
		}
		return products;
	}

	@Transactional
	public void qtyUpdateProduct(String name, int qty) {
		SQLQuery query = sessionfactory.getCurrentSession()
				.createSQLQuery("update Product2 set proQty=proQty-:qty where proname=:name ");
		query.setParameter("qty", qty);
		query.setParameter("name", name);
		query.addEntity(Product.class);
		query.executeUpdate();
	}
}
