package com.shoppersden.dao;

import java.util.List;

import com.shoppersden.model.MyOrders;

public interface MyOrderDaoIface {
	void addOrder(MyOrders myOrders);
	List<Integer> getOrders(String id);
	void cancelOrder(int oid);
}
