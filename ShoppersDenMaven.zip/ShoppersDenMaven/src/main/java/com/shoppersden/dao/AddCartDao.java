package com.shoppersden.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.shoppersden.model.Cart;

/**
 * @author Ankit
 *
 */
@Repository
public class AddCartDao implements AddCartDaoIface {
	private ArrayList<Cart> carts = null;

	public void setCart(ArrayList<Cart> cart) {
		this.carts = cart;
	}

	public String AddToCart(Cart cart) {
		int flag = 0;
		if (carts == null) {
			carts = new ArrayList<Cart>();
		}

		for (Cart cart1 : carts) {
			if (cart1.getName().equals(cart.getName())) {
				increaseQty(cart.getName());
				flag = 1;
			}
		}

		if (flag == 0) {
			carts.add(cart);
		}
		return "Added Successful";
	}

	public ArrayList<Cart> displayCart() {

		return carts;
	}

	public String removeCart(String name) {
		for (int i = 0; i < carts.size(); i++) {
			Cart p = carts.get(i);
			if (p.getName().equals(name)) {
				carts.remove(i);
			}
		}
		return "Removed";
	}

	public String decreaseQty(String name) {
		for (int i = 0; i < carts.size(); i++) {
			Cart p = carts.get(i);
			if (p.getName().equals(name)) {
				if (p.getcQty() == 1) {
					removeCart(name);
				} else {
					p.setcPrice(p.getcPrice() - p.getPrice());
					p.setcQty(p.getcQty() - 1);
				}
			}
		}
		return "decreased";
	}

	public String increaseQty(String name) {
		String str = null;
		for (int i = 0; i < carts.size(); i++) {
			Cart p = carts.get(i);
			if (p.getName().equals(name)) {
				if (p.getQty() <= p.getcQty()) {
					str = name + " is not sufficiently available";
				} else {
					p.setcPrice(p.getcPrice() + p.getPrice());
					p.setcQty(p.getcQty() + 1);
					str = "increased";
				}
			}
		}
		return str;
	}

	public int cartSize() {
		if (carts == null || carts.isEmpty()) {
			return 0;
		} else {
			return carts.size();
		}
	}
	
	
}
