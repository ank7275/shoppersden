package com.shoppersden.dao;

import com.shoppersden.model.Customer;

public interface CustomerDaoIface {
	String addCustomer(Customer cust);

	Customer verifyCustomer(String email, String pass);

	String updateCustomer(Customer customer);

	Customer getCustomerDetails(String uid);

	int validateId(String id);

	int updatePassword(String id, String pass);
}
