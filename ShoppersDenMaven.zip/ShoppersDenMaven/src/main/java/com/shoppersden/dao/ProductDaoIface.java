package com.shoppersden.dao;

import java.util.List;

import com.shoppersden.model.Product;

public interface ProductDaoIface {
	String addProduct(Product obj);

	String removeProduct(int id);

	String updateProduct(Product obj);

	List<Product> searchByCategory(int sid);

	List<Product> getAllProduct();

	List<Product> getAllProductAdmin(String name);

	Product getProduct(int id);

	List<Product> getProductsSearch(String val);

	void qtyUpdateProduct(String name, int qty);
}
