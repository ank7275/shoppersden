package com.shoppersden.dao;

import java.util.Calendar;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shoppersden.model.Transactions;

/**
 * @author Ankit
 *
 */
@Repository
public class TransactionDao implements TransactionDaoIface {
	@Autowired
	SessionFactory sessionFactory;

	Calendar calendar;

	@Transactional
	public void insertTransaction(Transactions transactions) {
		calendar = Calendar.getInstance();
		transactions.setOdate(calendar.getTime());
		calendar.add(Calendar.DAY_OF_MONTH, 3);
		transactions.setDdate(calendar.getTime());
		transactions.setStatus("pending");
		sessionFactory.getCurrentSession().save(transactions);
	}

	@Transactional
	public List<Transactions> getAllTransactions() {
		String status = "pending";
		List<Transactions> transactions = sessionFactory.getCurrentSession().createQuery("from Transactions").list();
		for (Transactions transactions2 : transactions) {
			if (!transactions2.getStatus().equals("cancelled")) {
				if (transactions2.getDdate().compareTo(Calendar.getInstance().getTime()) < 0) {
					transactions2.setStatus("delivered");
					status = "delivered";
				} else if (transactions2.getDdate().compareTo(Calendar.getInstance().getTime()) == 0) {
					transactions2.setStatus("on the way");
					status = "on the way";
				}
				Query query = sessionFactory.getCurrentSession()
						.createQuery("update Transactions set status=:status where trid=:id");
				query.setParameter("status", status);
				query.setParameter("id", transactions2.getTrId());
				query.executeUpdate();
			}
		}
		return transactions;
	}
}
