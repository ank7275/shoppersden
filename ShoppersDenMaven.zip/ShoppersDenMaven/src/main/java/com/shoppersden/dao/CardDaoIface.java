package com.shoppersden.dao;

import java.util.List;

import com.shoppersden.model.Card;

public interface CardDaoIface {
	String addCard(Card obj);

	String deleteCard(String cno);

	List<Card> getAllCard(String user);
}
