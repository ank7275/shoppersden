package com.shoppersden.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "orders1")
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column
	private int cid;
	@Column
	private int proid;
	@Column
	private String name;
	@Transient
	private int price;
	@Transient
	private int qty;
	@Column
	private int cQty = 1;
	@Column
	private int cPrice = 0;
	@Column
	private int oid;
	@ManyToOne
	@JoinColumn(name = "oid", referencedColumnName = "orderid", insertable = false, updatable = false)
	private MyOrders myOrders;

	public Cart() {

	}

	public Cart(int id, String name, int price, int qty) {
		super();
		this.proid = id;
		this.name = name;
		this.price = price;
		this.qty = qty;
		this.cPrice = price;
	}

	public MyOrders getMyOrders() {
		return myOrders;
	}

	public void setMyOrders(MyOrders myOrders) {
		this.myOrders = myOrders;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public int getProid() {
		return proid;
	}

	public void setProid(int proid) {
		this.proid = proid;
	}

	public int getOid() {
		return oid;
	}

	public void setOid(int oid) {
		this.oid = oid;
	}

	public int getcPrice() {
		return cPrice;
	}

	public void setcPrice(int cPrice) {
		this.cPrice = cPrice;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public int getcQty() {
		return cQty;
	}

	public void setcQty(int cQty) {
		this.cQty = cQty;
	}

}
