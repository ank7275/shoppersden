package com.shoppersden.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "transactions1")
public class Transactions {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column
	private int trId;
	@Column
	private String address;
	@Column
	private String totQty;
	@Temporal(TemporalType.DATE)
	@Column
	private Date ddate;
	@Temporal(TemporalType.DATE)
	@Column
	private Date odate;
	@Column
	private String totalAmt;
	@Column
	private String cardNo;
	@Column
	private String cName;
	@Column
	private String cAddress;
	@Column
	private String status;
	@Column
	private int oid;
	@OneToOne
	@JoinColumn(name = "oid", referencedColumnName = "orderid", insertable = false, updatable = false)
	private MyOrders myOrders;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getOid() {
		return oid;
	}

	public void setOid(int oid) {
		this.oid = oid;
	}

	public MyOrders getMyOrders() {
		return myOrders;
	}

	public void setMyOrders(MyOrders myOrders) {
		this.myOrders = myOrders;
	}

	public int getTrId() {
		return trId;
	}

	public void setTrId(int trId) {
		this.trId = trId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTotQty() {
		return totQty;
	}

	public void setTotQty(String totQty) {
		this.totQty = totQty;
	}

	public Date getDdate() {
		return ddate;
	}

	public void setDdate(Date ddate) {
		this.ddate = ddate;
	}

	public String getTotalAmt() {
		return totalAmt;
	}

	public void setTotalAmt(String totalAmt) {
		this.totalAmt = totalAmt;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public String getcAddress() {
		return cAddress;
	}

	public void setcAddress(String cAddress) {
		this.cAddress = cAddress;
	}

	public Date getOdate() {
		return odate;
	}

	public void setOdate(Date odate) {
		this.odate = odate;
	}

}
