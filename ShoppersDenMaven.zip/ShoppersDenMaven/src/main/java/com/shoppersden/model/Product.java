package com.shoppersden.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "product2")
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column
	private int proId;
	@Column
	@Pattern(message="Enter Name",regexp="(^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$)")
	private String proName;
	@Column
	@NotEmpty
	private String proDesc;
	@Column
	private String proImg;
	@Column
	private int catId;
	@Column
	@Pattern(regexp="[0-9]{1,2}",message="Enter product Quantity")
	private String proQty;
	@Column
	@Pattern(regexp="[0-9]{1,6}",message="Enter Price")
	private String proPrice;
	@Column
	private String postedBy;

	public int getProId() {
		return proId;
	}

	public void setProId(int proId) {
		this.proId = proId;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public String getProDesc() {
		return proDesc;
	}

	public void setProDesc(String proDesc) {
		this.proDesc = proDesc;
	}

	public String getProImg() {
		return proImg;
	}

	public void setProImg(String proImg) {
		this.proImg = "/ShoppersDenMaven/resources/shopping/" + proImg;
	}

	public String getProQty() {
		return proQty;
	}

	public void setProQty(String proQty) {
		this.proQty = proQty;
	}

	public String getProPrice() {
		return proPrice;
	}

	public void setProPrice(String proPrice) {
		this.proPrice = proPrice;
	}

	public String getPostedBy() {
		return postedBy;
	}

	public void setPostedBy(String postedBy) {
		this.postedBy = postedBy;
	}

	public int getCatId() {
		return catId;
	}

	public void setCatId(int catId) {
		this.catId = catId;
	}

}
