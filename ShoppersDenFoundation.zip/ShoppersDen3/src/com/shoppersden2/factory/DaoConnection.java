package com.shoppersden2.factory;

import java.sql.Connection;
import org.apache.log4j.Logger;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

//data access object
public class DaoConnection {
	static Logger logger = Logger.getLogger(DaoConnection.class);

	public static Connection getConnection() {
		ResourceBundle resource = ResourceBundle.getBundle("ResourceBundle");
		String path = resource.getString("DB_DRIVER_CLASS");
		String url = resource.getString("DB_URL");
		String user = resource.getString("DB_USERNAME");
		String pwd = resource.getString("DB_PASSWORD");
		try {
			Class.forName(path);
			Connection con = DriverManager.getConnection(url, user, pwd);
			return con;
		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e.getMessage());
		}
		return null;
	}
}
