package com.shoppersden2.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.shoppersden2.factory.DaoConnection;

public class ValidateIdController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(ValidateIdController.class);

	public ValidateIdController() {
		super();

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Connection connection = DaoConnection.getConnection();
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection.prepareStatement("select count(*) d from customer where u_email=?");
			preparedStatement.setString(1, request.getParameter("name"));
			ResultSet rs = preparedStatement.executeQuery();
			rs.next();
			if (rs.getInt("d") > 0) {
				response.sendRedirect("changepassword.jsp?id=" + request.getParameter("name"));
			} else {
				response.sendRedirect("ForgotPassword.jsp?msg=Invalid id");
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

	}

}
