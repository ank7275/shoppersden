package com.shoppersden2.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.shoppersden2.dao.ProductDao;
import com.shoppersden2.model.Product;

public class UpdateProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(UpdateProductController.class);

	public UpdateProductController() {
		super();
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			int id = Integer.parseInt(request.getParameter("id"));
			String name = request.getParameter("name");
			String path = request.getParameter("path");
			String desc = request.getParameter("desc");
			int category = Integer.parseInt(request.getParameter("type"));
			int price = Integer.parseInt(request.getParameter("price"));
			int qty = Integer.parseInt(request.getParameter("qty"));
			Product obj = new Product();
			obj.setProId(id);
			obj.setProName(name);
			obj.setProImg(path);
			obj.setCatId(category);
			obj.setProPrice(price);
			obj.setProQty(qty);
			obj.setProDesc(desc);
			new ProductDao().updateProduct(obj);
			response.sendRedirect("AdminController");
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

}
