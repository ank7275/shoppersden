package com.shoppersden2.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shoppersden2.dao.CategoryDao;
import com.shoppersden2.dao.ProductDao;
import com.shoppersden2.model.Category;
import com.shoppersden2.model.Product;

public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AdminController() {
		super();

	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		ArrayList<Product> products = new ProductDao().getAllProductAdmin((String) session.getAttribute("name"));
		ArrayList<Category> categories = new CategoryDao().getAllCategory();
		ServletContext context = getServletContext();
		context.setAttribute("category", categories);
		request.setAttribute("product", products);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("Admin.jsp");
		requestDispatcher.forward(request, response);
	}

}
