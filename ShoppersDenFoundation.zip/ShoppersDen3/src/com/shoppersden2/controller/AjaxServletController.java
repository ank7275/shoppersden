package com.shoppersden2.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.shoppersden2.dao.ProductDao;
import com.shoppersden2.model.Product;

public class AjaxServletController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(AjaxServletController.class);

	public AjaxServletController() {
		super();

	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String s = request.getParameter("val");
			ArrayList<Product> products = new ProductDao().getProductsSearch(s);
			request.setAttribute("products", products);
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("Search.jsp");
			requestDispatcher.forward(request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

	}

}
