package com.shoppersden2.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.shoppersden2.factory.DaoConnection;

public class UpdatePasswordController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(UpdatePasswordController.class);

	public UpdatePasswordController() {
		super();
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Connection connection = DaoConnection.getConnection();
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection.prepareStatement("update customer set u_pwd=? where u_email=?");
			preparedStatement.setString(2, request.getParameter("name"));
			preparedStatement.setString(1, request.getParameter("pass"));
			preparedStatement.executeUpdate();
			response.sendRedirect("Loginform.jsp?msg=Password changed");
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

	}

}
