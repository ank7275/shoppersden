package com.shoppersden2.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.shoppersden2.dao.CategoryDao;

public class AddCategoryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(AddCategoryController.class);

	public AddCategoryController() {
		super();

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String name = request.getParameter("CategoryName");
			if (new CategoryDao().addCategory(name).equals("Category cannot be added")) {
				response.sendRedirect("Category.jsp?msg=Category already exist");
			} else {
				response.sendRedirect("ViewCategoryController");
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

}
