package com.shoppersden2.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.shoppersden2.dao.ProductDao;
import com.shoppersden2.model.Product;

public class AddProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(AddProductController.class);

	public AddProductController() {
		super();

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			HttpSession session = request.getSession();
			String name = request.getParameter("name");
			String path = request.getParameter("path");
			String desc = request.getParameter("desc");
			int category = Integer.parseInt(request.getParameter("type"));
			int price = Integer.parseInt(request.getParameter("price"));
			int qty = Integer.parseInt(request.getParameter("qty"));
			Product product = new Product();
			product.setProName(name);
			product.setProImg(path);
			product.setCatId(category);
			product.setProPrice(price);
			product.setProDesc(desc);
			product.setProQty(qty);
			product.setPostedBy((String) session.getAttribute("name"));
			response.sendRedirect("Productform.jsp?msg=" + new ProductDao().addProduct(product));
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

}
