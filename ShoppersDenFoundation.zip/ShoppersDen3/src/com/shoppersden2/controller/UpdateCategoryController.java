package com.shoppersden2.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.shoppersden2.dao.CategoryDao;

public class UpdateCategoryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(UpdateCategoryController.class);

	public UpdateCategoryController() {
		super();

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			int id = Integer.parseInt(request.getParameter("cid"));
			String name = request.getParameter("c_name");
			new CategoryDao().updateCategory(id, name);
			response.sendRedirect("ViewCategoryController");
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

}
