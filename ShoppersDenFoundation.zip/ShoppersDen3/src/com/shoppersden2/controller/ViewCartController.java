package com.shoppersden2.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shoppersden2.dao.AddCartDao;
import com.shoppersden2.model.Cart;

public class ViewCartController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ViewCartController() {
		super();
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (AddCartDao.l == null || AddCartDao.cartSize() == 0) {
			request.setAttribute("msg1", "Cart is empty");
		} else {
			ArrayList<Cart> carts = AddCartDao.displayCart();
			request.setAttribute("cart", carts);
			request.setAttribute("msg", request.getAttribute("msg"));
		}
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("ViewCart.jsp");
		requestDispatcher.forward(request, response);
	}
}
