package com.shoppersden2.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.shoppersden2.dao.AddCartDao;

public class IncreaseQtyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(IncreaseQtyController.class);

	public IncreaseQtyController() {
		super();

	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String str = AddCartDao.increaseQty(request.getParameter("name"));
			if (str.equals("increased")) {
				response.sendRedirect("ViewCartController");
			} else {
				request.setAttribute("msg", str);
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("ViewCartController");
				requestDispatcher.forward(request, response);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

	}

}
