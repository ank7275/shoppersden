package com.shoppersden2.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.shoppersden2.dao.CategoryDao;
import com.shoppersden2.dao.ProductDao;
import com.shoppersden2.model.Category;
import com.shoppersden2.model.Product;

public class WelcomeServletController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(WelcomeServletController.class);

	public WelcomeServletController() {
		super();
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			ServletContext context = getServletContext();

			ArrayList<Product> products = new ProductDao().getAllProduct();
			ArrayList<Category> categories = new CategoryDao().getAllCategory();
			request.setAttribute("product", products);
			context.setAttribute("category", categories);

			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
}
