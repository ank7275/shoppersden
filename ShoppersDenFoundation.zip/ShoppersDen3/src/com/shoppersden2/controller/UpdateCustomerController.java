package com.shoppersden2.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.shoppersden2.dao.CustomerDao;
import com.shoppersden2.model.Customer;

public class UpdateCustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(UpdateCustomerController.class);

	public UpdateCustomerController() {
		super();

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			Customer customer = new Customer();
			customer.setcEmail(request.getParameter("cEmail"));
			customer.setcAddress(request.getParameter("cAddress"));
			customer.setcContact(request.getParameter("cContact"));
			customer.setcPass(request.getParameter("cPass"));
			request.setAttribute("msg", new CustomerDao().updateCustomer(customer));
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("CustomerController");
			requestDispatcher.forward(request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

	}

}
