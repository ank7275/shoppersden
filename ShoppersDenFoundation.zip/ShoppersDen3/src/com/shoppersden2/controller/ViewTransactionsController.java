package com.shoppersden2.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.shoppersden2.dao.AdminDao;
import com.shoppersden2.model.MyOrders;

public class ViewTransactionsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger;

	public ViewTransactionsController() {
		super();

	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			HttpSession session = request.getSession();
			ArrayList<MyOrders> myOrders = new AdminDao().getAllTransactions((String) session.getAttribute("name"));
			request.setAttribute("transactions", myOrders);
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("Transactions.jsp");
			requestDispatcher.forward(request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

}
