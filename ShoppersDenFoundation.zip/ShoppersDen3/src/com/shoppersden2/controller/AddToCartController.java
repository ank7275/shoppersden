package com.shoppersden2.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.shoppersden2.dao.AddCartDao;
import com.shoppersden2.model.Cart;

public class AddToCartController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(AddToCartController.class);

	public AddToCartController() {
		super();

	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			HttpSession session = request.getSession();
			int id = Integer.parseInt(request.getParameter("id"));
			String name = request.getParameter("name");
			int price = Integer.parseInt(request.getParameter("price"));
			int qty = Integer.parseInt(request.getParameter("qty"));
			Cart obj = new Cart(id, name, price, qty);
			AddCartDao.AddToCart(obj);
			if (session.getAttribute("cname") == null) {
				response.sendRedirect("WelcomeServletController");
			} else {
				response.sendRedirect("CustomerController");
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

}
