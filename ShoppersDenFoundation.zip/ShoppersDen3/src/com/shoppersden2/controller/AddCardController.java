package com.shoppersden2.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.shoppersden2.dao.CardDao;
import com.shoppersden2.model.Card;

public class AddCardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(AddCardController.class);

	public AddCardController() {
		super();

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String cno = request.getParameter("cNo");
			String uid = request.getParameter("uId");
			String cvv = request.getParameter("cvv");
			int expmonth = Integer.parseInt(request.getParameter("expMonth"));
			int expYear = Integer.parseInt(request.getParameter("expYear"));
			String cholder = request.getParameter("cardHolder");
			Card obj = new Card();
			obj.setCno(cno);
			obj.setUid(uid);
			obj.setCccv(cvv);
			obj.setCexpMonth(expmonth);
			obj.setCexpYear(expYear);
			obj.setChName(cholder);
			new CardDao().addCard(obj);
			response.sendRedirect("ViewCardsController");
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

}
