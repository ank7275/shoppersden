package com.shoppersden2.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.shoppersden2.dao.AdminDao;

public class AddAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(AddAdminController.class);

	public AddAdminController() {
		super();

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String name = request.getParameter("aName");
			String pass = request.getParameter("aPass");
			AdminDao obj = new AdminDao();
			String msg = obj.registerAdmin(name, pass);
			RequestDispatcher requestDispatcher = request
					.getRequestDispatcher("AdminRegister.jsp?msg=Your admin id is " + msg);
			requestDispatcher.forward(request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

	}

}
