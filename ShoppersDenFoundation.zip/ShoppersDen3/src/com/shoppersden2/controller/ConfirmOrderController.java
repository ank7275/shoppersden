package com.shoppersden2.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.shoppersden2.dao.AddCartDao;
import com.shoppersden2.dao.MyOrderDao;
import com.shoppersden2.dao.TransactionDao;
import com.shoppersden2.model.Cart;

public class ConfirmOrderController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(ConfirmOrderController.class);

	public ConfirmOrderController() {
		super();

	}

	static void cartResize() {
		AddCartDao.l = null;
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String address = null;
			if (request.getParameter("naddress") != null) {
				address = request.getParameter("naddress");
			} else {
				address = request.getParameter("Address");
			}
			HttpSession session = request.getSession();
			int totQty = Integer.parseInt(request.getParameter("totQty"));
			int totAmt = Integer.parseInt(request.getParameter("totAmount"));
			new TransactionDao().insertTransaction(totQty, address, totAmt);
			ArrayList<Cart> cart = AddCartDao.displayCart();
			cartResize();
			for (Cart c : cart) {
				new MyOrderDao().addOrder(c.getName(), c.getcQty(), c.getId(), (String) session.getAttribute("cname"));
			}
			request.setAttribute("cart", cart);
			RequestDispatcher requestDispatcher = request
					.getRequestDispatcher("Confirm.jsp?totqty=" + totQty + "&totamt=" + totAmt + "&add=" + address);
			requestDispatcher.forward(request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

}
