package com.shoppersden2.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.shoppersden2.dao.AdminDao;
import com.shoppersden2.dao.CustomerDao;

public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(LoginController.class);

	public LoginController() {
		super();
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			HttpSession session = request.getSession();
			String name = request.getParameter("name");
			String pass = request.getParameter("pass");
			String user = new AdminDao().verifyAdmin(name.toUpperCase(), pass);
			if (!user.equals("Invalid")) {
				session.setAttribute("name", user);
				RequestDispatcher rd = request.getRequestDispatcher("AdminController");
				rd.forward(request, response);
			} else if (new CustomerDao().verifyCustomer(name, pass) == 1) {
				session.setAttribute("cname", name);
				RequestDispatcher rd = request.getRequestDispatcher("CustomerController");
				rd.forward(request, response);
			} else {
				RequestDispatcher rd = request.getRequestDispatcher("Loginform.jsp?msg=Invalid Credentials");
				rd.include(request, response);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
}
