package com.shoppersden2.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.shoppersden2.factory.DaoConnection;

public class MyOrderDao {
	static Logger logger = Logger.getLogger(MyOrderDao.class);
	public void addOrder(String name,int qty,int id,String cname) {
		Connection connection=DaoConnection.getConnection();
		try {
			CallableStatement callableStatement1 = connection.prepareCall("{call prcaddtocart(?,?,?,?)}");
			CallableStatement callableStatement2 = connection.prepareCall("{call prcUpdatePdb(?,?)}");
			callableStatement1.setInt(1, id);
			callableStatement1.setInt(2, qty);
			callableStatement1.setString(3, name);
			callableStatement1.setString(4, cname);
			callableStatement1.execute();
			callableStatement2.setInt(1, id);
			callableStatement2.setInt(2, qty);
			callableStatement2.execute();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
	}
}
