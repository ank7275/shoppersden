package com.shoppersden2.dao;


import java.util.ArrayList;

import com.shoppersden2.model.Cart;

public class AddCartDao {
	public static ArrayList<Cart> l = null;

	public static String AddToCart(Cart obj) {
		int flag = 0;
		if (l == null) {
			l = new ArrayList<Cart>();
		}

		for (Cart cart : l) {
			if (cart.getName().equals(obj.getName())) {
				increaseQty(obj.getName());
				flag = 1;
			}
		}

		if (flag == 0) {
			l.add(obj);
		}
		return "Added Successful";
	}

	public static ArrayList<Cart> displayCart() {
		ArrayList<Cart> list = l;

		return list;
	}

	public static String removeCart(String name) {
		l.removeIf(p -> p.getName().equals(name));
		return "Removed";
	}

	public static String decreaseQty(String name) {
		for (int i = 0; i < l.size(); i++) {
			Cart p = l.get(i);
			if (p.getName().equals(name)) {
				if (p.getcQty() == 1) {
					removeCart(name);
				} else {
					p.setcPrice(p.getcPrice() - p.getPrice());
					p.setcQty(p.getcQty() - 1);
				}
			}
		}
		return "decreased";
	}

	public static String increaseQty(String name) {
		for (int i = 0; i < l.size(); i++) {
			Cart p = l.get(i);
			if (p.getName().equals(name)) {
				if (p.getQty() <= p.getcQty()) {
					return name + " is not sufficiently available";
				} else {
					p.setcPrice(p.getcPrice() + p.getPrice());
					p.setcQty(p.getcQty() + 1);
				}
			}
		}
		return "increased";
	}

	public static int cartSize() {
		return l.size();
	}
}
