package com.shoppersden2.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.shoppersden2.factory.DaoConnection;
import com.shoppersden2.model.Card;

public class CardDao {
	static Logger logger = Logger.getLogger(Card.class);
	Connection connection;
	CallableStatement callableStatement;

	public String addCard(Card obj) {
		if (obj != null) {
			connection = DaoConnection.getConnection();
			String cmd = "{call PrcAddCard(?,?,?,?,?,?)}";
			try {
				callableStatement = connection.prepareCall(cmd);
				callableStatement.setString(1, obj.getCno());
				callableStatement.setString(2, obj.getUid());
				callableStatement.setString(3, obj.getCccv());
				callableStatement.setInt(4, obj.getCexpMonth());
				callableStatement.setInt(5, obj.getCexpYear());
				callableStatement.setString(6, obj.getChName());
				callableStatement.executeUpdate();
				return "Card Added Successfully...";
			} catch (SQLException e) {
				logger.error(e.getMessage());
				return e.getMessage();
			}
		} else {
			return "Enter card details...";
		}
	}

	public String deleteCard(String cno) {
		if (cno != null) {
			connection = DaoConnection.getConnection();
			try {
				callableStatement = connection.prepareCall("{call prcDelCard(?)}");
				callableStatement.setString(1, cno);
				callableStatement.execute();
				return "Record Deleted..";
			} catch (SQLException e) {
				logger.error(e.getMessage());
				return e.getMessage();
			}
		} else {
			return "Card cannot be deleted...";
		}
	}
	public ArrayList<Card> getAllCard(String user){
		ArrayList<Card> cards=new ArrayList<Card>();
		if(user == null) {
			return cards;
		}
	    connection = DaoConnection.getConnection();
		String cmd = "select * from cards where u_id=?";
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(cmd);
			pst.setString(1, user);
			ResultSet resultSet = pst.executeQuery();
			while(resultSet.next()) {
				Card card=new Card();
				card.setCno(resultSet.getString(1));
				card.setUid(resultSet.getString(2));
				card.setCccv(resultSet.getString(3));
				card.setCexpMonth(resultSet.getInt(4));
				card.setCexpYear(resultSet.getInt(5));
				card.setChName(resultSet.getString(6));
				cards.add(card);
			}
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return cards;
	
	}


}
