package com.shoppersden2.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;

import com.shoppersden2.factory.DaoConnection;
import com.shoppersden2.model.Customer;
import com.shoppersden2.model.MyOrders;

public class CustomerDao {
	Connection connection;
	static Logger logger = Logger.getLogger(Customer.class);

	public String addCustomer(Customer c) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MMM-yy");
		Date date = null;
		try {
			date = sdf.parse(c.getcDob());
		} catch (ParseException e1) {
			logger.error(e1.getMessage());
			return e1.getMessage();
		}

		connection = DaoConnection.getConnection();
		try {
			CallableStatement callableStatement = connection.prepareCall("{call prcCreateNewCustomer(?,?,?,?,?,?,?)}");
			callableStatement.setString(1, c.getcName());
			callableStatement.setString(2, c.getcGender());
			callableStatement.setString(3, c.getcAddress());
			callableStatement.setString(4, c.getcEmail());
			callableStatement.setString(5, c.getcContact());
			callableStatement.setString(6, sdf1.format(date));
			callableStatement.setString(7, c.getcPass());
			callableStatement.execute();
			return "Customer Account created";
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return e.getMessage();
		}

	}

	public int verifyCustomer(String email, String pass) {
		connection = DaoConnection.getConnection();
		String str = "{call prcVerifyCustomer(?,?,?)}";
		try {

			CallableStatement callableStatement = connection.prepareCall(str);
			callableStatement.setString(1, email);
			callableStatement.setString(2, pass);
			callableStatement.registerOutParameter(3, Types.INTEGER);
			callableStatement.execute();
			int i = callableStatement.getInt(3);
			return i;
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return 0;

	}

	public String updateCustomer(Customer customer) {
		if (customer != null) {
			CallableStatement callableStatement;
			try {
				connection=DaoConnection.getConnection();
				callableStatement = connection.prepareCall("{ call prcUpdateCustomer(?,?,?,?)}");
				callableStatement.setString(1, customer.getcAddress());
				callableStatement.setString(2, customer.getcEmail());
				callableStatement.setString(3, customer.getcContact());
				callableStatement.setString(4, customer.getcPass());
				callableStatement.executeUpdate();

			} catch (SQLException e) {
                logger.error(e.getMessage());
			}
			return "Successfully updated";
		}
		return "Not updated";
	}

	public Customer getCustomerDetails(String uid) {
		if(uid == null) {
			return null;
		}
		Customer customer=new Customer();
		PreparedStatement preparedStatement;
		try {
			connection=DaoConnection.getConnection();
			preparedStatement = connection.prepareStatement("SELECT * FROM customer  where u_email=?");
			preparedStatement.setString(1, uid);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
			
				customer.setcAddress(rs.getString(4));
				customer.setcName(rs.getString(2));
				customer.setcGender(rs.getString(3));
				customer.setcContact(rs.getString(6));
				customer.setcDob(rs.getString(7));
				customer.setcPass(rs.getString(8));
				customer.setcEmail(uid);
			}
		} catch (SQLException e) {
          logger.error(e.getMessage());
		}
		return customer;
	}

	public ArrayList<MyOrders> getAllOrders(String uid) {
		ArrayList<MyOrders> myOrders1 = new ArrayList<MyOrders>();
		String sql = "SELECT * FROM cart Where u_id=? ";
		connection = DaoConnection.getConnection();
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, uid);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				MyOrders myOrders = new MyOrders();
				myOrders.setProId(rs.getInt(1));
				myOrders.setProName(rs.getString(2));
				myOrders.setQty(rs.getInt(3));
				myOrders.setAdddate(rs.getDate(4));
				myOrders1.add(myOrders);
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return myOrders1;
	}

}
