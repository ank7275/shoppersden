package com.shoppersden2.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.shoppersden2.factory.DaoConnection;

public class TransactionDao {
	static Logger logger = Logger.getLogger(TransactionDao.class);
	public void insertTransaction(int totQty,String address,int totAmount) {
		Connection connection = DaoConnection.getConnection();
		try {
			CallableStatement callableStatement = connection.prepareCall("{call prcTransaction(?,?,?)}");
			callableStatement.setInt(1, totQty);
			callableStatement.setString(2, address);
			callableStatement.setInt(3, totAmount);
			callableStatement.execute();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
	}

}
