package com.shoppersden2.dao;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.shoppersden2.factory.DaoConnection;
import com.shoppersden2.model.Admin;
import com.shoppersden2.model.MyOrders;

public class AdminDao {
	Connection connection;
	CallableStatement callableStatement;
	static Logger logger = Logger.getLogger(Admin.class);

	public String registerAdmin(String id, String password) {
		connection = DaoConnection.getConnection();
		try {
			callableStatement = connection.prepareCall("{call prcAdminRegister(?,?,?)}");
			callableStatement.setString(1, id);
			callableStatement.setString(2, password);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.execute();
			String str = callableStatement.getString(3);
			return str;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return e.getMessage();
		}
	}

	public String verifyAdmin(String id, String pass) {

		connection = DaoConnection.getConnection();
		String sql = "{call prcverifyadmin(?,?,?)}";
		try {
			callableStatement = connection.prepareCall(sql);
			callableStatement.setString(1, id);
			callableStatement.setString(2, pass);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.execute();
			String i = callableStatement.getString(3);
			return i;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return e.getMessage();
		}
	}

	public ArrayList<MyOrders> getAllTransactions(String userid) {
		ArrayList<MyOrders> myOrderesultSet = new ArrayList<MyOrders>();
		String sql = "SELECT c.p_id,c.p_name,c.qty,c.add_date,c.u_id FROM cart c INNER JOIN product p ON c.p_id=p.p_id AND p.p_admin=?";
		connection = DaoConnection.getConnection();
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, userid);
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				MyOrders orderesultSet = new MyOrders();
				orderesultSet.setProId(resultSet.getInt(1));
				orderesultSet.setProName(resultSet.getString(2));
				orderesultSet.setQty(resultSet.getInt(3));
				orderesultSet.setAdddate(resultSet.getDate(4));
				orderesultSet.setUid(resultSet.getString(5));
				myOrderesultSet.add(orderesultSet);
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return myOrderesultSet;

	}
}
