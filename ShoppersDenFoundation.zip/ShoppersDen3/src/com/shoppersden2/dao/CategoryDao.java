package com.shoppersden2.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.shoppersden2.factory.DaoConnection;
import com.shoppersden2.model.Category;

public class CategoryDao {
	Connection connection;
	PreparedStatement preparedStatement;
	CallableStatement callableStatement;
	static Logger logger = Logger.getLogger(Category.class);

	public String addCategory(String name) {
		if (name != null) {
			connection = DaoConnection.getConnection();
			String cmd = "{call PrcAddCate(?,?)}";
			try {
				callableStatement = connection.prepareCall(cmd);
				callableStatement.setInt(1, new CategoryDao().generateCategoryId());
				callableStatement.setString(2, name);
				callableStatement.execute();
				return "Category Added Successfully...";
			} catch (SQLException e) {
				logger.error(e.getMessage());
				return "Category cannot be added";
			}
		} else {
			return "Category cannot be added";
		}
	}

	public int generateCategoryId() {
		connection = DaoConnection.getConnection();

		try {
			callableStatement = connection.prepareCall("{call prcgenerateCid(?)}");
			callableStatement.registerOutParameter(1, Types.INTEGER);
			callableStatement.execute();
			return callableStatement.getInt(1);
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return 0;
	}

	public String updateCategory(int cid, String cname) {
		if (cid > 0 && cname != null) {
			connection = DaoConnection.getConnection();
			try {

				callableStatement = connection.prepareCall("{call updatecateg(?,?)}");
				callableStatement.setInt(1, cid);
				callableStatement.setString(2, cname);
				callableStatement.execute();
				return "updated successfully..";
			} catch (SQLException e) {
				logger.error(e.getMessage());
				return e.getMessage();
			}
		} else {
			return "Category cannot be updated";
		}
	}

	public String deleteCategory(int cid) {
		if (cid > 0) {
			connection = DaoConnection.getConnection();
			try {
				callableStatement = connection.prepareCall("{call deletecateg(?)}");
				callableStatement.setInt(1, cid);
				callableStatement.execute();
				return "Record Deleted..";
			} catch (SQLException e) {
				logger.error(e.getMessage());
				return e.getMessage();
			}
		} else {
			return "Record cannot be deleted";
		}
	}

	public  ArrayList<Category> getAllCategory() {
		ArrayList<Category> categories = new ArrayList<Category>();
		connection = DaoConnection.getConnection();
		try {
			preparedStatement = connection.prepareStatement("select * from category");
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Category category = new Category();
				category.setCatId(resultSet.getInt(1));
				category.setCatName(resultSet.getString(2));
				categories.add(category);
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return categories;
	}
	public Category getCategory(int id) {
		if(id<=0) {
			return null;
		}
		Category category=null;
	    connection = DaoConnection.getConnection();
		String cmd = "select * from Category where c_id=?";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			preparedStatement.setInt(1, id);
			ResultSet rs = preparedStatement.executeQuery();
			if(rs.next()) {
			    category=new Category();
				category.setCatId(id);
				category.setCatName(rs.getString(2));
			}
	
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return category;
	}

}
