package com.shoppersden2.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.shoppersden2.factory.DaoConnection;
import com.shoppersden2.model.Product;

public class ProductDao {
	static Logger logger = Logger.getLogger(Product.class);
	Connection connection;
	CallableStatement callableStatement;
	PreparedStatement preparedStatement;

	public String addProduct(Product obj) {
		if (obj == null) {
			return "product cannot be null";
		} else {
			connection = DaoConnection.getConnection();
			String sql = "{call prcaddproduct(?,?,?,?,?,?,?)}";
			try {
				callableStatement = connection.prepareCall(sql);
				callableStatement.setString(1, obj.getProName());
				callableStatement.setString(2, obj.getProImg());
				callableStatement.setInt(3, obj.getCatId());
				callableStatement.setString(4, obj.getProDesc());
				callableStatement.setInt(5, obj.getProPrice());
				callableStatement.setInt(6, obj.getProQty());
				callableStatement.setString(7, obj.getPostedBy());
				callableStatement.execute();

			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
			return "product added";
		}
	}

	public String removeProduct(int id) {
		connection = DaoConnection.getConnection();
		if (id > 0) {
			String sql = "{call DELETEPRODUCT(?)}";
			try {
				callableStatement = connection.prepareCall(sql);
				callableStatement.setInt(1, id);
				callableStatement.execute();
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
			return "Product deleted";
		} else {
			return "product cannot be deleted";
		}
	}

	public String updateProduct(Product obj) {
		if (obj != null) {
			connection = DaoConnection.getConnection();
			String sql = "{call updateproduct(?,?,?,?,?,?,?)}";
			try {
				callableStatement = connection.prepareCall(sql);
				callableStatement.setInt(1, obj.getProId());
				callableStatement.setString(2, obj.getProName());
				callableStatement.setString(3, obj.getProImg());
				callableStatement.setInt(4, obj.getCatId());
				callableStatement.setString(5, obj.getProDesc());
				callableStatement.setInt(6, obj.getProPrice());
				callableStatement.setInt(7, obj.getProQty());
				callableStatement.execute();
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}

			return "Successfully updated";
		} else {
			return "Product cannot be update";
		}
	}

	public Product[] searchByCategory(int sid) {

		connection = DaoConnection.getConnection();
		Product[] c = null;
		try {
			preparedStatement = connection
					.prepareStatement("select count(*) cnt from product where p_c_Id=? and p_qty>0");
			preparedStatement.setInt(1, sid);
			ResultSet resultSet = preparedStatement.executeQuery();
			resultSet.next();
			int cnt = resultSet.getInt("cnt");
			c = new Product[cnt];
			preparedStatement = connection
					.prepareStatement("select p_Img,p_Name,P_desc,p_qty,price from product where p_c_Id=? and p_qty>0");
			preparedStatement.setInt(1, sid);
			resultSet = preparedStatement.executeQuery();
			Product c1 = null;
			int i = 0;

			while (resultSet.next()) {
				c1 = new Product();
				c1.setProImg(resultSet.getString("p_Img"));
				c1.setProName(resultSet.getString("p_Name"));
				c1.setProPrice(resultSet.getInt("Price"));
				c1.setProDesc(resultSet.getString("p_desc"));
				c1.setProQty(resultSet.getInt("p_qty"));
				c[i] = c1;
				i++;
			}

		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return c;
	}

	public ArrayList<Product> getAllProduct() {
		ArrayList<Product> products = new ArrayList<Product>();
		connection = DaoConnection.getConnection();
		try {
			preparedStatement = connection.prepareStatement("SELECT * FROM product WHERE p_qty>0");
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Product product = new Product();
				product.setProImg(resultSet.getString(3));
				product.setProId(resultSet.getInt(1));
				product.setProName(resultSet.getString(2));
				product.setProDesc(resultSet.getString(5));
				product.setProPrice(resultSet.getInt(6));
				product.setProQty(resultSet.getInt(7));
				products.add(product);
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return products;
	}

	public ArrayList<Product> getAllProductAdmin(String name) {
		ArrayList<Product> products = new ArrayList<Product>();
		if (name == null) {
			return products;
		}
		connection = DaoConnection.getConnection();
		try {
			preparedStatement = connection.prepareStatement("SELECT * FROM product WHERE p_admin=?");
			preparedStatement.setString(1, name);
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Product product = new Product();
				product.setProImg(resultSet.getString(3));
				product.setProId(resultSet.getInt(1));
				product.setProName(resultSet.getString(2));
				product.setProDesc(resultSet.getString(5));
				product.setProPrice(resultSet.getInt(6));
				product.setProQty(resultSet.getInt(7));
				products.add(product);
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return products;
	}

	public Product getProduct(int id) {
		Product product = new Product();
		connection = DaoConnection.getConnection();
		try {
			preparedStatement = connection.prepareStatement("SELECT * FROM product where p_id=?");
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				product.setProImg(resultSet.getString(3));
				product.setProId(resultSet.getInt(1));
				product.setProName(resultSet.getString(2));
				product.setProDesc(resultSet.getString(5));
				product.setProPrice(resultSet.getInt(6));
				product.setProQty(resultSet.getInt(7));
				product.setCatId(resultSet.getInt(4));
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return product;
	}

	public ArrayList<Product> getProductsSearch(String val) {
		ArrayList<Product> products = new ArrayList<Product>();
		try {
			connection = DaoConnection.getConnection();
			if (val == null || val.trim().equals("")) {
				products = new ProductDao().getAllProduct();

			} else {
				preparedStatement = connection
						.prepareStatement("SELECT * FROM product where p_qty>0 AND (lower(p_name) like '" + val
								+ "%' OR initcap(p_name) like '" + val + "%')");
				ResultSet resultSet = preparedStatement.executeQuery();
				while (resultSet.next()) {
					Product product = new Product();
					product.setProImg(resultSet.getString(3));
					product.setProId(resultSet.getInt(1));
					product.setProName(resultSet.getString(2));
					product.setProDesc(resultSet.getString(5));
					product.setProPrice(resultSet.getInt(6));
					product.setProQty(resultSet.getInt(7));
					product.setCatId(resultSet.getInt(4));
					products.add(product);
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return products;
	}

}
