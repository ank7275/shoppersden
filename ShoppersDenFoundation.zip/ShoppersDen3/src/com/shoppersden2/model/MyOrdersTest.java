package com.shoppersden2.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MyOrdersTest {

	@Test
	public void testGetters() {
		
		MyOrders myorder=new MyOrders();
		
		myorder.setProId(0);
		assertEquals(0,myorder.getProId());
		
		myorder.setProName("saloon");
		assertEquals("saloon",myorder.getProName());
		
		myorder.setQty(56);
		assertEquals(56,myorder.getQty());
		
		
		myorder.setUid("aa@gmail.com");
		assertEquals("aa@gmail.com",myorder.getUid());
	}

}
