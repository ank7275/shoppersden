package com.shoppersden2.model;

public class Customer {
	private int cId;
	private String cName;
	private String cGender;
	private String cAddress;
	private String cEmail;
	private String cContact;
	private String cDob;
	private String cPass;
	private String cQuery;
	private String cAns;

	public int getcId() {
		return cId;
	}

	public void setcId(int cId) {
		this.cId = cId;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public String getcGender() {
		return cGender;
	}

	public void setcGender(String cGender) {
		this.cGender = cGender;
	}

	public String getcAddress() {
		return cAddress;
	}

	public void setcAddress(String cAddress) {
		this.cAddress = cAddress;
	}

	public String getcEmail() {
		return cEmail;
	}

	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}

	public String getcContact() {
		return cContact;
	}

	public void setcContact(String cContact) {
		this.cContact = cContact;
	}

	public String getcDob() {
		return cDob;
	}

	public void setcDob(String cDob) {
		this.cDob = cDob;
	}

	public String getcPass() {
		return cPass;
	}

	public void setcPass(String cPass) {
		this.cPass = cPass;
	}

	public String getcQuery() {
		return cQuery;
	}

	public void setcQuery(String cQuery) {
		this.cQuery = cQuery;
	}

	public String getcAns() {
		return cAns;
	}

	public void setcAns(String cAns) {
		this.cAns = cAns;
	}

}
