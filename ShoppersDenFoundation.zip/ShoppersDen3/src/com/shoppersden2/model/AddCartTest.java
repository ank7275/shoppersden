package com.shoppersden2.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.shoppersden2.dao.AddCartDao;

class AddCartTest {

	@Test
	public void addToCarttest() {
		Cart obj = new Cart(1, "oil", 34, 5);
		assertEquals("Added Successful", AddCartDao.AddToCart(obj));
	}

	@Test
	public void decreaseQty() {
		assertEquals("decreased", AddCartDao.decreaseQty("oil"));
	}

	@Test
	public void increaseQty() {
		assertEquals("increased", AddCartDao.increaseQty("oil"));
	}

	@Test
	public void removeQty() {
		assertEquals("Removed", AddCartDao.removeCart("oil"));
	}

	@Test
	public void sizeTest() {
		assertEquals(AddCartDao.l.size(), AddCartDao.cartSize());
	}

}
