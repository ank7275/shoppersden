package com.shoppersden2.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import com.shoppersden2.dao.CategoryDao;
import com.shoppersden2.factory.DaoConnection;

class CategoryTest {

	@Test
	public void testGetters() {
		Category obj = new Category();
		obj.setCatId(1);
		assertEquals(1, obj.getCatId());

		obj.setCatName("Mens");
		assertEquals("Mens", obj.getCatName());

	}

	@Test
	public void testConnection() {
		assertNotNull(DaoConnection.getConnection());
	}

	@Test
	public void testAddCategory() {
		assertEquals("Category Added Successfully...", new CategoryDao().addCategory("Mens"));
		assertEquals("Category cannot be added", new CategoryDao().addCategory(null));
	}

	@Test
	public void testUpdateCategory() {
		assertEquals("updated successfully..", new CategoryDao().updateCategory(1, "Mens"));
		assertEquals("Category cannot be updated", new CategoryDao().updateCategory(-1, null));
		assertEquals("Category cannot be updated", new CategoryDao().updateCategory(1, null));
	}

	@Test
	public void testDeleteCategory() {
		assertEquals("Record Deleted..", new CategoryDao().deleteCategory(1));
		assertEquals("Record cannot be deleted", new CategoryDao().deleteCategory(-1));
	}

}
