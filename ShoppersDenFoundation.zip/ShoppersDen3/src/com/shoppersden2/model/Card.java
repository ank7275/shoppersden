package com.shoppersden2.model;

public class Card {
	private String cno;
	private String uid;
	private String cccv;
	private int cexpMonth;
	private int cexpYear;
	private String chName;

	public String getCno() {
		return cno;
	}

	public void setCno(String cno) {
		this.cno = cno;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getCccv() {
		return cccv;
	}

	public void setCccv(String cccv) {
		this.cccv = cccv;
	}

	public int getCexpMonth() {
		return cexpMonth;
	}

	public void setCexpMonth(int cexpMonth) {
		this.cexpMonth = cexpMonth;
	}

	public int getCexpYear() {
		return cexpYear;
	}

	public void setCexpYear(int cexpYear) {
		this.cexpYear = cexpYear;
	}

	public String getChName() {
		return chName;
	}

	public void setChName(String chName) {
		this.chName = chName;
	}

}
