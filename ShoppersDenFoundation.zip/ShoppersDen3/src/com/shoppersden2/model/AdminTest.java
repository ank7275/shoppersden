package com.shoppersden2.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.shoppersden2.dao.AdminDao;
import com.shoppersden2.factory.DaoConnection;

class AdminTest {
	@Test
	public void testGetters() {
		Admin obj = new Admin();

		obj.setAdminName("Ankit");
		assertEquals("Ankit", obj.getAdminName());

		obj.setAdminPassword("ankit");
		assertEquals("ankit", obj.getAdminPassword());

	}

	@Test
	public void testConnection() {
		assertNotNull(DaoConnection.getConnection());
	}

	@Test
	public void testRegisterAdmin() {
		assertNotNull(new AdminDao().registerAdmin("ravi", "pas"));
		assertNull(new AdminDao().registerAdmin(null, null));

	}

	public void testVerifyAdmin() {

		assertEquals("Invalid", new AdminDao().verifyAdmin("null", "null"));
		assertEquals("Indralok", new AdminDao().verifyAdmin("ADMIN001", "Ankit@123"));
	}

}
