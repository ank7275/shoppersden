package com.shoppersden2.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.shoppersden2.dao.CustomerDao;

class CustomerTest {

	@Test
	public void testAddCustomer() {
		Customer obj1 = new Customer();
		obj1.setcId(1);
		obj1.setcGender("MALE");
		obj1.setcEmail("Vijay@gmail.com");
		obj1.setcDob("03-11-1996");
		obj1.setcContact("9540221967");
		obj1.setcAddress("Hyderabad");
		obj1.setcName("Vijay");
		obj1.setcPass("Vijay@000");
		assertEquals("customer Account created", new CustomerDao().addCustomer(obj1));

	}

	@Test
	public void testVerifyCustomer() {
		CustomerDao obj = new CustomerDao();
		int a = obj.verifyCustomer("ankit@gmail.com", "demo");
		if (a == 1) {
			assertEquals(1, a);
		} else {
			assertEquals(0, a);
		}
	}

}
