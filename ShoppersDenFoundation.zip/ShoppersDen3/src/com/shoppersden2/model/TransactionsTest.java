package com.shoppersden2.model;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

class TransactionsTest {
	@Test
	public void testGetters() {
		Transactions transactions = new Transactions();

		transactions.setTrId("TR001");
		assertEquals("TR001", transactions.getTrId());

		transactions.setSadd("address");
		assertEquals("address", transactions.getSadd());

		transactions.setQty(5);
		assertEquals(5, transactions.getQty());

		transactions.setDdate(null);
		assertEquals(null, transactions.getDdate());

		transactions.setTrdate(null);
		assertEquals(null, transactions.getTrdate());

		transactions.setAmt(677);
		assertEquals(677, transactions.getAmt());

	}

}
