package com.shoppersden2.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CartTest {

	@Test
	public void testGetters() {
		Cart obj = new Cart(5, "oil", 456, 6);
		obj.setId(5);
		assertEquals(5, obj.getId());
		obj.setName("oil");
		assertEquals("oil", obj.getName());
		obj.setPrice(333);
		assertEquals(333, obj.getPrice());
		obj.setQty(9);
		assertEquals(9, obj.getQty());
		obj.setcPrice(344);
		assertEquals(344, obj.getcPrice());
		obj.setcQty(3);
		assertEquals(3, obj.getcQty());
	}

}
