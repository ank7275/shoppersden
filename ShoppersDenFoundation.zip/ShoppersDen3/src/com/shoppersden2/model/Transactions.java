package com.shoppersden2.model;

import java.util.Date;

public class Transactions {
	private String trId;
	private String sadd;
	private int qty;
	private Date ddate;
	private Date trdate;
	private int amt;

	public String getTrId() {
		return trId;
	}

	public void setTrId(String trId) {
		this.trId = trId;
	}

	public String getSadd() {
		return sadd;
	}

	public void setSadd(String sadd) {
		this.sadd = sadd;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public Date getDdate() {
		return ddate;
	}

	public void setDdate(Date ddate) {
		this.ddate = ddate;
	}

	public Date getTrdate() {
		return trdate;
	}

	public void setTrdate(Date trdate) {
		this.trdate = trdate;
	}

	public int getAmt() {
		return amt;
	}

	public void setAmt(int amt) {
		this.amt = amt;
	}

}
