package com.shoppersden.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="card1")
public class Card {
	@Id
	@Column
	@Pattern(regexp="[0-9]{13,16}",message="Enter valid card number")
	private String cno;
	@Column
	private String userid;
	@Column
	@Pattern(regexp="[0-9]{3}",message="Enter the 3 digit CVV no")
	private String cccv;
	@Column
	@Pattern(regexp="(0[1-9]|1[0-2])",message="Enter the valid month")
	private String cexpMonth;
	@Column
	@Pattern(regexp="(0[0-2]|1[0-9]|2[0-5])", message="Enter the year upto 25")
	private String cexpYear;
	@Column
	@Pattern(regexp="[a-zA-Z]+",message="must be Alphabetical")
	private String chName;

	public String getCno() {
		return cno;
	}
	public void setCno(String cno) {
		this.cno = cno;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getCccv() {
		return cccv;
	}

	public void setCccv(String cccv) {
		this.cccv = cccv;
	}

	public String getCexpMonth() {
		return cexpMonth;
	}

	public void setCexpMonth(String cexpMonth) {
		this.cexpMonth = cexpMonth;
	}

	public String getCexpYear() {
		return cexpYear;
	}

	public void setCexpYear(String cexpYear) {
		this.cexpYear = cexpYear;
	}

	public String getChName() {
		return chName;
	}

	public void setChName(String chName) {
		this.chName = chName;
	}

}
