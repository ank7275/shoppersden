package com.shoppersden.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "customer1")
public class Customer {
	@Column
	private String cName;
	@Column
	private String cGender;
	@Column
	private String cAddress;
	@Id
	@Column
	private String cEmail;
	@Column
	private String cContact;
	@Column
	private String cDob;
	@Column
	private String cPass;
	@Column
	private String cQuery;
	@Column
	private String cAns;

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public String getcGender() {
		return cGender;
	}

	public void setcGender(String cGender) {
		this.cGender = cGender;
	}

	public String getcAddress() {
		return cAddress;
	}

	public void setcAddress(String cAddress) {
		this.cAddress = cAddress;
	}

	public String getcEmail() {
		return cEmail;
	}

	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}

	public String getcContact() {
		return cContact;
	}

	public void setcContact(String cContact) {
		this.cContact = cContact;
	}

	public String getcDob() {
		return cDob;
	}

	public void setcDob(String cDob) {
		this.cDob = cDob;
	}

	public String getcPass() {
		return cPass;
	}

	public void setcPass(String cPass) {
		this.cPass = cPass;
	}

	public String getcQuery() {
		return cQuery;
	}

	public void setcQuery(String cQuery) {
		this.cQuery = cQuery;
	}

	public String getcAns() {
		return cAns;
	}

	public void setcAns(String cAns) {
		this.cAns = cAns;
	}

}
