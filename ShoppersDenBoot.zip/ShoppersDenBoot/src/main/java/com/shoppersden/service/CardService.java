package com.shoppersden.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shoppersden.dao.CardDaoIface;
import com.shoppersden.model.Card;

@Service
public class CardService implements CardServiceIface {
	@Autowired
	CardDaoIface aCardDaoIface;

	
	public String addCardService(Card obj) {
		return aCardDaoIface.addCard(obj);
	}

	public String deleteCardService(String cno) {
		return aCardDaoIface.deleteCard(cno);
	}

	
	public List<Card> getAllCardService(String user) {
		return aCardDaoIface.getAllCard(user);
	}

}
