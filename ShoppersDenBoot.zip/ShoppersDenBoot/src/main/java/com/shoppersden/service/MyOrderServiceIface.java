package com.shoppersden.service;

import java.util.List;

import com.shoppersden.model.MyOrders;

public interface MyOrderServiceIface {
	void addOrderService(MyOrders myOrders);
	List<Integer> getOrdersService(String id);
	void cancelOrderService(int oid);
}
