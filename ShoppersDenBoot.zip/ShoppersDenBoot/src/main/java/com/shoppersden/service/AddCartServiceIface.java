package com.shoppersden.service;

import java.util.ArrayList;

import com.shoppersden.model.Cart;

public interface AddCartServiceIface {
	String AddToCartService(Cart obj);
	ArrayList<Cart> displayCartService();
	String removeCartService(String name);
	String decreaseQtyService(String name);
	String increaseQtyService(String name);
	int cartSize();
    void setCart(ArrayList<Cart> cart);
}
