package com.shoppersden.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shoppersden.dao.ProductDaoIface;
import com.shoppersden.model.Product;
@Service
public class ProductService implements ProductServiceIface {
    @Autowired
	ProductDaoIface productDaoIface;

	
	public String addProductService(Product obj) {
		return productDaoIface.addProduct(obj);
	}

	
	public String removeProductService(int id) {
		return productDaoIface.removeProduct(id);
	}

	public String updateProductService(Product obj) {
		return productDaoIface.updateProduct(obj);
	}

	
	public List<Product> searchByCategoryService(int sid) {
		return productDaoIface.searchByCategory(sid);
	}

	
	public List<Product> getAllProductService() {
		return productDaoIface.getAllProduct();
	}

	
	public List<Product> getAllProductAdminService(String name) {
		return productDaoIface.getAllProductAdmin(name);
	}

	
	public Product getProductService(int id) {
		return productDaoIface.getProduct(id);
	}

	
	public List<Product> getProductsSearchService(String val) {
		return productDaoIface.getProductsSearch(val);
	}
	public void qtyUpdateProductService(String name,int qty) {
		productDaoIface.qtyUpdateProduct(name, qty);
	}
}
