package com.shoppersden.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.shoppersden.dao.CardDao;
import com.shoppersden.model.Card;

class CardTest {

	@Test
	public void testGetters() {
		Card obj = new Card();
		obj.setUserid("1");
		assertEquals("1", obj.getUserid());
		obj.setCno("2361873469737");
		assertEquals("2361873469737", obj.getCno());
		obj.setChName("Amita");
		assertEquals("Amita", obj.getChName());
		obj.setCexpYear("2019");
		assertEquals("2019", obj.getCexpYear());
		obj.setCexpMonth("04");
		assertEquals("04", obj.getCexpMonth());
		obj.setCccv("345");
		assertEquals("345", obj.getCccv());

	}

	@Test
	public void testAddCard() {
		Card obj = new Card();
		obj.setUserid("2");
		obj.setCno("2361873469737");
		obj.setChName("Amita");
		obj.setCexpMonth("08");
		obj.setCexpYear("2019");
		obj.setCccv("345");
		assertEquals("Card Added Successfully...", new CardDao().addCard(obj));
		assertEquals("Enter card details...", new CardDao().addCard(null));
	}

	@Test
	public void testDeleteCard() {
		assertEquals("Card Deleted..", new CardDao().deleteCard("2361873469737"));
		assertEquals("Card cannot be deleted...", new CardDao().deleteCard(null));
	}

}