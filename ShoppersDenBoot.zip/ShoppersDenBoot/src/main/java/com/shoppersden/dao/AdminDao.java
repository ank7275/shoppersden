package com.shoppersden.dao;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shoppersden.model.Admin;

@Repository
public class AdminDao implements AdminDaoIface {

	@Autowired
	SessionFactory sessionFactory;

	static Logger logger = Logger.getLogger(Admin.class);

	@Transactional
	public String registerAdmin(Admin admin) {
		String msg = this.checkEmailExistance(admin.getAdminEmail());
		if (msg == null) {
			String i = (String) sessionFactory.getCurrentSession().save(admin);
			if (i != null) {
				return "Successfully Registered";
			} else {
				return "Not Registered";
			}
		}else {
			return "Use different email address";
		}
	}

	@Transactional
	public Admin verifyAdmin(String adminId, String adminPass) {
		Admin admin = (Admin) sessionFactory.getCurrentSession().get(Admin.class, adminId);
		if (admin != null) {
			if (admin.getAdminPassword().equals(adminPass)) {
				return admin;
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	@Transactional
	public String checkEmailExistance(String adminId) {
		Admin admin = (Admin) sessionFactory.getCurrentSession().get(Admin.class, adminId);
		if (admin != null) {
			return "email already exists";
		} else {
			return null;
		}
	}

}
