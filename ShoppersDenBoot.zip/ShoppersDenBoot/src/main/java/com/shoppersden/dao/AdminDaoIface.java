package com.shoppersden.dao;

import com.shoppersden.model.Admin;

public interface AdminDaoIface {
	String registerAdmin(Admin admin);

	Admin verifyAdmin(String id, String pass);
	
	String checkEmailExistance(String adminId);
}
