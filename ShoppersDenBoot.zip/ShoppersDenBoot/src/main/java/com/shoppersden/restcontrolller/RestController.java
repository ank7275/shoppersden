package com.shoppersden.restcontrolller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;

import com.shoppersden.model.Category;
import com.shoppersden.model.Product;
import com.shoppersden.service.CategoryServiceIface;
import com.shoppersden.service.ProductServiceIface;

/**
 * @author Ankit
 *
 */
@org.springframework.web.bind.annotation.RestController
public class RestController {
	@Autowired
	ProductServiceIface productServiceIface;
	@Autowired
	CategoryServiceIface categoryServiceIface;
	
	@GetMapping(value = "/getAllProductsJSON",produces = "application/json")
	public List<Product> getAllProductRest(){
		return productServiceIface.getAllProductService();
	}
	
	@GetMapping(value ="/getAllCategoryXML", produces = {MediaType.APPLICATION_XML_VALUE})
	public List<Category> getAllCategory(){
		return categoryServiceIface.showCategoryService();
	}

}
